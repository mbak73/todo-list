\# TODO list

A simple app to manage your daily tasks.

It uses HTML5 and CSS3.



\## Features

* List of daily tasks



License:MIT

